from django import template
register = template.Library()

@register.filter(name = 'curency')
def curency(number):
    return "₹ "+str(number)