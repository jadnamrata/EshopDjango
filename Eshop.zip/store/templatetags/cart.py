from django import template

register = template.Library()

@register.filter(name = 'is_in_cart')
def is_in_cart(product,cart):
    cart1 = cart['cart']
    keys_cart = cart1.keys()
    # print('--------before--------->cart dict is    ', cart1)
    removed_val = cart1.pop('null','no key found')
    # print('-------after---------->cart dict is    ',cart1)
    # print(removed_val)
    # print(keys_cart)
    for k1 in keys_cart:
        # print(k1,type(k1))
        # if k1:
        # print(product.id,type(product.id))
        if int(k1)==product.id:
            return True
    # print(product, cart1)
    return False

@register.filter(name = 'cart_quantity')
def cart_quantity(product,cart):
    cart1 = cart['cart']
    keys_cart = cart1.keys()
    for k1 in keys_cart:
        if int(k1)==product.id:
            return cart1.get(k1)
    return 0

@register.filter(name = 'cart_total')
def cart_total(product,cart):
    total = product.price*cart_quantity(product,cart)
    return total

@register.filter(name = 'cart_final_total')
def cart_final_total(products,cart):
    final_total= 0
    for p in products:
        final_total += cart_total(p,cart)
    return final_total



@register.filter(name = 'multiply')
def multiply(num1,num2):
    return num1*num2