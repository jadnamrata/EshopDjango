from django.db import models
from store.models.category import Category
import datetime
from store.models.product import Product
from store.models.customer import Customer

class Order(models.Model):
    customer = models.ForeignKey(Customer,on_delete=models.CASCADE)
    product = models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity = models.IntegerField()
    price = models.IntegerField()
    phone = models.IntegerField()
    address = models.CharField(max_length=89,default = '')
    date = models.DateField(default=datetime.datetime.today())
    status = models.BooleanField(default=False)
    class Meta:
        db_table='Order'

    @staticmethod
    def get_orders_by_customer_id(customer):
        print('order execution....')
        return Order.objects.filter(customer=customer)






    # def customer_orders(self):
