
from django.db import models

class Category(models.Model):
    name = models.CharField(max_length=56)
    class Meta:
        db_table = 'Category'

    @staticmethod
    def get_all_categories():
        return Category.objects.all()

    def __str__(self):   #to show proper object name  in table view of admin site
        return self.name