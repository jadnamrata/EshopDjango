from django.db import models
class Customer(models.Model):
    first_name= models.CharField(max_length=90,default=None)
    last_name = models.CharField(max_length=90)
    contact = models.BigIntegerField(default=None)
    email= models.EmailField(default = None)
    password = models.CharField(max_length=500,default=None)
    class Meta:
        db_table = 'Customer'

    def isExists(self):
        c1 = Customer.objects.filter(email=self.email)
        if c1:
            return True
        return False

    @staticmethod
    def get_customer_byEmail(email):
        try:
            return Customer.objects.get(email = email)
        except:
            return False
