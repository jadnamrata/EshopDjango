from django.db import models
from store.models.category import Category

class Product(models.Model):       #product:category===M:1
    name = models.CharField(max_length=13)
    price= models.FloatField()
    description = models.CharField(max_length=500,default='',null=True,blank=True)
    image = models.ImageField(upload_to='uploads/products')
    category = models.ForeignKey(Category,on_delete=models.CASCADE,default=1)
    class Meta:
        db_table = 'Product'

    @staticmethod
    def get_product_by_id_in_cart(ids):
        return Product.objects.filter(id__in=ids)

    @staticmethod
    def get_all_products():
        return Product.objects.all()

    @staticmethod
    def get_product_by_id(prodid):
        return Product.objects.filter(category = prodid)