from django.shortcuts import render, redirect
from django.http import HttpResponse
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from store.models.order import Order
from django.contrib.auth.hashers import check_password, make_password
from django.views import View
from store.middleware.auth import auth_middleware
from django.utils.decorators import method_decorator



class OrdersView(View):

    # @method_decorator(auth_middleware)
    def get(self,request):
        customer = request.session.get('customer')
        print(customer,type(customer))
        cus_orders = Order.get_orders_by_customer_id(customer)
        cus_orders=list(cus_orders)
        cus_orders.reverse()
        return render(request,'orders.html',{'cus_orders':cus_orders})