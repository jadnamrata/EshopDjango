from django.shortcuts import render, redirect
from django.http import HttpResponse
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.contrib.auth.hashers import check_password, make_password
from django.views import View
#<QueryDict: {'csrfmiddlewaretoken': ['MuJKL0hfUyyFHJWH7GWLvdZJKa24e0mK8Z2vv1UkFSIVNX838T3IBwpNCxnB4mVS'],
# 'address': ['nalstop'], 'phone': ['950'], 'check out': ['Submit']}>
from store.models.order import Order
class Checkout(View):
    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        products = Product.get_product_by_id_in_cart(list(cart.keys()))

        for product in products:
            order = Order(customer=Customer(id = customer), product =product ,
                          quantity= cart.get(str(products[0].id)), price = product.price,
                          phone=phone, address=address)
            print(address, phone, customer, cart, product, cart.get(str(products[0].id)),product.price)
            order.save()
            print('order is saved in orders table...')
        request.session['cart'] = {}

        return redirect('cart')







