from django.shortcuts import render,redirect
from django.http import HttpResponse
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.contrib.auth.hashers import check_password,make_password
from django.views import View
# Create your views here.
class Index(View):
    def get(self,request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart']={}
        # del request.session['cart']
        # request.session.get('cart').clear()
        products = Product.get_all_products()
        categories = Category.get_all_categories()
        userCategory_id = request.GET.get('category ')

        if userCategory_id:
            products = Product.get_product_by_id(userCategory_id)
        print('you are: ', request.session.get('customer_email'))
        return render(request, 'index.html', {'products': products,
                                              'categories': categories})  # return render(request, 'orders/order.html')     # return render(request, 'base.html')               # return render(request, 'orders/order.html')

    def post(self,request):
        print('product added to cart is ---',request.POST.get('prod_id'))
        prod_id = request.POST.get('prod_id')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(prod_id)
            if quantity:
                if remove:
                    if quantity<=1:
                        cart.pop(prod_id)
                    else:
                        cart[prod_id] = quantity-1
                else:
                    cart[prod_id]=1+quantity
            else:
                cart[prod_id] = 1
        else:
            cart = {}
            cart[prod_id] = 1
        request.session['cart'] = cart
        print('cart-----',request.session.get('cart'))
        return redirect('homepage')
