from django.shortcuts import render,redirect
from django.http import HttpResponse
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.contrib.auth.hashers import check_password,make_password
from django.views import View

class Signup(View):
    def get(self,request):
        return render(request,'signup.html')
    def post(self,request):
        f_name = request.POST.get('name')
        l_name = request.POST.get('surname')
        contact_no = request.POST.get('contact')
        pwd = request.POST.get('Password')
        email = request.POST.get('email')
        c = Customer(first_name=f_name, last_name=l_name, contact=contact_no, email=email, password=pwd)
        value = {'f_name': f_name, 'l_name': l_name, 'contact_no': contact_no, 'email': email}
        error_msg = None
        if not c.first_name:
            error_msg = 'First name is required...'
        elif len(c.first_name) < 4:
            error_msg = 'Firstname must be atleast 4 char...'
        elif not c.last_name:
            error_msg = 'Last name is required...'
        elif len(c.last_name) < 4:
            error_msg = 'lastname must be atleast 4 char...'
        elif not c.contact:
            error_msg = 'contact details required...'
        elif not c.password:
            error_msg = 'password is required...'
        elif len(c.password) < 4:
            error_msg = 'password must be atleast 4 char...'
        elif c.isExists():
            error_msg = 'email is already registered...'
        if not error_msg:
            c.password = make_password(c.password)
            c.save()
            return redirect('homepage')
        data = {'error': error_msg, 'value': value}
        return render(request, 'signup.html', {'error': error_msg, 'value': value})